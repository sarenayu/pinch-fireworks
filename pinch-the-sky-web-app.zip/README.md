# Pinch the Sky

A local browser experience that uses MediaPipe Hand Landmarker to detect a thumb-to-index-finger pinch and launch a firework over the supplied night-sky photo.

## Run it

The camera only works from `localhost` (or HTTPS), so do not open `index.html` directly.

1. Open a terminal in this folder.
2. Run `python -m http.server 8000 --directory dist`.
3. Visit `http://localhost:8000` in Chrome or Edge.
4. Select **Enable camera**, allow camera access, then bring your thumb and index finger together.

Open your fingers before pinching again. The app uses separate close/release thresholds, a two-frame confirmation, and a short cooldown so a held pinch triggers only one burst.

The first load needs an internet connection to download MediaPipe’s browser library and hand-tracking model. Camera video is processed locally in the browser and is not uploaded by this app.
